function y=mycc(X)
y=exp(-X)+sin(X)+cos(3*X)+0.2*X+1;
end
clc
clear all
tic
rng(1)
n=4;k=1000;
lb=[0];ub=[4];
X=lhsdesign(n,1);
X(:,1)=4*X(:,1);    
Y=mycc(X);
xc=linspace(lb,ub,k)';
theta=0.1;%�趨��ʼֵ  mle��ֵ �Ҽ�ֵ��
lob=0.01;
upb=100;
for i=1:2
    figure (i)
    miny=min(Y);
    dmodel=dacefit(X,Y,@regpoly0, @corrgauss, theta,lob,upb);
    XN=ga(@(x)myei(x,miny,dmodel),1,[],[],[],[],lb,ub);
    YN=mycc(XN);
    for t=1:k
        yei(t)=-myei(xc(t),miny,dmodel);
    end
    % EIͼ
    subplot(2,1,2)
    plot(xc,yei)
    hold on
    scatter(XN,-myei(XN,miny,dmodel))
    hold off
    % ����ͼ
    theta=0.1;%�趨��ʼֵ  mle��ֵ �Ҽ�ֵ��
    lob=0.01;
    upb=100;
    dmodel=dacefit(X,Y,@regpoly0, @corrgauss,theta,lob,upb);
    yy=predictor(xc,dmodel);
    subplot(2,1,1)
    plot(xc,yy,'b')
    hold on 
    yt=mycc(xc);
    plot(xc,yt,'r--')
    hold on
    scatter(X,Y,'bo');
    scatter(XN,YN,'ro','markerfacecolor','r')
    legend('Ԥ�⺯��','��ʵ����','ԭʼ������','�¼�������')
    hold off
    X=[X;XN];
    Y=[Y;YN];    
end
toc
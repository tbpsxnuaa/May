function y=myei(x0,miny,dmodel)
[yp,~,sq,~]=predictor(x0,dmodel);
s=sqrt(sq);
ei=(miny-yp)*normcdf(miny,yp,s)+s*normpdf(miny,yp,s);
y=-ei;
end